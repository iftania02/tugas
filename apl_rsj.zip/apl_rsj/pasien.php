<?php
// membuat instance
$datapasien=NEW Pasien;
// aksi tampil data
if($_GET['aksi']=='tampil'){
// aksi untuk tampil data
$html = null;
$html .='<h3>Daftar Spp</h3>';
$html .='<p>Berikut ini data </p>';
$html .='<table border="1" width="100%">
<thead>
<th>No.</th>
<th>Id Pasien</th>
<th>Nama Siswa</th>
<th>Tempat Lahir</th>
<th>Tanggal Lahir</th>
<th>Jenis Kelamin</th>
<th>Alamat</th>
<th>Aksi</th>
</thead>
<tbody>';
// variabel $data menyimpan hasil return
$data = $datapasien->tampil();
$no=null;
if(isset($data)){
foreach($data as $barisPasien){
$no++;
$html .='<tr>
<td>'.$no.'</td>
<td>'.$barisPasien->id_pasien.'</td>
<td>'.$barisPasien->nama.'</td>
<td>'.$barisPasien->kelas.'</td>
<td>'.$barisPasien->tempat_lahir.'</td>
<td>'.$barisPasien->tanggl_lahir.'</td>
<td>'.$barisPasien->jenis_kelamin.'</td>
<td>'.$barisPasien->alamat.'</td>
<td>
<a href="index.php?file=pasien&aksi=edit&id_pasien='.$barisPasien->id_pasien.'">Edit</a>
<a href="index.php?file=pasien&aksi=hapus&id_pasien='.$barisPasien->id_pasien.'">Hapus</a>
</td>
</tr>';
}
}
$html .='</tbody>
</table>';
echo $html;
}
// aksi tambah data
else if ($_GET['aksi']=='tambah') {
$html =null;
$html .='<h3>Form Tambah</h3>';
$html .='<p>Silahkan masukan form </p>';
$html .='<form method="POST"action="index.php?file=spp&aksi=simpan">';
$html .='<p>Id Pasien<br/>';
$html .='<input type="text" name="txtId"placeholder="Masukan Id Pasien" autofocus/></p>';
$html .='<p>Nama<br/>';
$html .='<input type="text" name="txtNama"placeholder="Masukan Nama " size="30" required/></p>';
$html .='<p>Tempat, Tanggal Lahir<br/>';
$html .='<input type="text" name="txtTempatLahir"placeholder="Masukan Tempat Lahir" size="30" required/>,';
$html .='<input type="date" name="txtTglLahir"required/></p>';
$html .='<p>Jenis Kelamin<br/>';
$html .='<input type="radio" name="txtJenisKelamin"value="L"> Laki-laki';
$html .='<input type="radio" name="txtJenisKelamin"value="P"> Perempuan</p>';
$html .='<p>Alamat<br/>';
$html .='<input type="text" name="txtAlamat"placeholder="Masukan Alamat " size="30" required/></p>';
$html .='<p><input type="submit" name="tombolSimpan"value="Simpan"/></p>';
$html .='</form>';
echo $html;
}
// aksi tambah data
else if ($_GET['aksi']=='simpan') {
$data=array(
'id_pasien'=>$_POST['txtId'],
'nama'=>$_POST['txtNama'],
'tempat_lahir'=>$_POST['txtTempatLahir'],
'tgl_lahir'=>$_POST['txtTglLahir'],
'jenis_kelamin'=>$_POST['txtJenisKelamin'],
'alamat'=>$_POST['txtAlamat']
);
$datapasien->simpan($data);
echo '<meta http-equiv="refresh" content="0;
url=index.php?file=spp&aksi=tampil">';
}
else if ($_GET['aksi']=='edit') {
$pasien=$datapasien->detail($_GET['id_pasien']);
if($pasien->jenis_kelamin =='L') { $pilihL='checked';
$pilihP =null; }
else {
$pilihP='checked'; $pilihL =null; }
$html =null;
$html .='<h3>Form Tambah</h3>';
$html .='<p>Silahkan masukan form </p>';
$html .='<form method="POST"action="index.php?file=spp&aksi=update">';
$html .='<p>Id Pasien<br/>';
$html .='<input type="text" name="txtId"value="'.$pasien->id_pasien.'" placeholder="Masukan Id Pasien"readonly/></p>';
$html .='<p>Nama<br/>';
$html .='<input type="text" name="txtNama"value="'.$pasien->nama.'" placeholder="Masukan Nama  "size="30" required autofocus/></p>';
$html .='<p>Tempat, Tanggal Lahir<br/>';
$html .='<input type="text" name="txtTempatLahir"value="'.$pasien->tempat_lahir .'" placeholder="Masukan TempatLahir" size="30" required/>,';
$html .='<input type="date" name="txtTglLahir"value="'.$pasien->tgl_lahir.'" required/></p>';
$html .='<p>Jenis Kelamin<br/>';
$html .='<input type="radio" name="txtJenisKelamin"value="L" '.$pilihL.'> Laki-laki';
$html .='<input type="radio" name="txtJenisKelamin"value="P" '.$pilihP.'> Perempuan</p>';
$html .='<p>Alamat<br/>';
$html .='<input type="text" name="txtProgram"value="'.$pasien->alamat.'" placeholder="Masukan Program Keahlian  "size="30" required autofocus/></p>';
$html .='<p><input type="submit" name="tombolSimpan"value="Simpan"/></p>';
$html .='</form>';
echo $html;
}
// aksi tambah data
else if ($_GET['aksi']=='update') {
$data=array(
'nama'=>$_POST['txtNama'],
'tempat_lahir'=>$_POST['txtTempatLahir'],
'tgl_lahir'=>$_POST['txtTglLahir'],
'jenis_kelamin'=>$_POST['txtJenisKelamin'],
'alamat'=>$_POST['txtAlamat']
);
$datapasien->update($_POST['txtId'],$data);
echo '<meta http-equiv="refresh" content="0;
url=index.php?file=spp&aksi=tampil">';
}
// aksi tambah data
else if ($_GET['aksi']=='hapus') {
$datapasien->hapus($_GET['id_pasien']);
echo '<meta http-equiv="refresh" content="0;url=index.php?file=pasien&aksi=tampil">';
}
// aksi tidak terdaftar
else {
echo '<p>Error 404 : Halaman tidak ditemukan !</p>';
}
?>

